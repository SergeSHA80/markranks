const Department = require('../models/department');

exports.getDepartments = async (req, res) => {
  try {
    const departments = await Department.findAll();
    res.json(departments);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при получении подразделений' });
  }
};

exports.createDepartment = async (req, res) => {
  try {
    const { name } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: 'Название подразделения обязательно' });
    }
    
    const department = await Department.create({ name });
    res.status(201).json(department);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при создании подразделения' });
  }
};

exports.updateDepartment = async (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: 'Название подразделения обязательно' });
    }
    
    const department = await Department.findByPk(id);
    if (!department) {
      return res.status(404).json({ error: 'Подразделение не найдено' });
    }
    
    department.name = name;
    await department.save();
    
    res.json(department);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при обновлении подразделения' });
  }
};

exports.deleteDepartment = async (req, res) => {
  try {
    const { id } = req.params;
    
    const department = await Department.findByPk(id);
    if (!department) {
      return res.status(404).json({ error: 'Подразделение не найдено' });
    }
    
    await department.destroy();
    res.json({ message: 'Подразделение успешно удалено' });
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при удалении подразделения' });
  }
};

const { Customer, Department } = require('../models');

exports.getCustomers = async (req, res) => {
  try {
    const customers = await Customer.findAll({
      include: [{ model: Department, attributes: ['id', 'name'] }]
    });
    res.json(customers);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при получении заказчиков' });
  }
};

exports.createCustomer = async (req, res) => {
  try {
    const { name, departmentId } = req.body;
    
    if (!name || !departmentId) {
      return res.status(400).json({ error: 'Название и подразделение обязательны' });
    }
    
    const customer = await Customer.create({ name, departmentId });
    res.status(201).json(customer);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при создании заказчика' });
  }
};

exports.updateCustomer = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, departmentId } = req.body;
    
    if (!name || !departmentId) {
      return res.status(400).json({ error: 'Название и подразделение обязательны' });
    }
    
    const customer = await Customer.findByPk(id);
    if (!customer) {
      return res.status(404).json({ error: 'Заказчик не найден' });
    }
    
    customer.name = name;
    customer.departmentId = departmentId;
    await customer.save();
    
    res.json(customer);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при обновлении заказчика' });
  }
};

exports.deleteCustomer = async (req, res) => {
  try {
    const { id } = req.params;
    
    const customer = await Customer.findByPk(id);
    if (!customer) {
      return res.status(404).json({ error: 'Заказчик не найден' });
    }
    
    await customer.destroy();
    res.json({ message: 'Заказчик успешно удален' });
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при удалении заказчика' });
  }
};

// Для формы оценки
exports.getCustomersByDepartment = async (req, res) => {
  try {
    const { departmentId } = req.query;
    
    if (!departmentId) {
      return res.status(400).json({ error: 'ID подразделения обязательно' });
    }
    
    const customers = await Customer.findAll({
      where: { departmentId },
      attributes: ['id', 'name']
    });
    
    res.json(customers);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при получении заказчиков' });
  }
};

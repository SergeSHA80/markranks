const Specialist = require('../models/specialist');

exports.getSpecialists = async (req, res) => {
  try {
    const specialists = await Specialist.findAll();
    res.json(specialists);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при получении специалистов' });
  }
};

exports.createSpecialist = async (req, res) => {
  try {
    const { fullName } = req.body;
    
    if (!fullName) {
      return res.status(400).json({ error: 'ФИО специалиста обязательно' });
    }
    
    const specialist = await Specialist.create({ fullName });
    res.status(201).json(specialist);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при создании специалиста' });
  }
};

exports.updateSpecialist = async (req, res) => {
  try {
    const { id } = req.params;
    const { fullName } = req.body;
    
    if (!fullName) {
      return res.status(400).json({ error: 'ФИО специалиста обязательно' });
    }
    
    const specialist = await Specialist.findByPk(id);
    if (!specialist) {
      return res.status(404).json({ error: 'Специалист не найден' });
    }
    
    specialist.fullName = fullName;
    await specialist.save();
    
    res.json(specialist);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при обновлении специалиста' });
  }
};

exports.deleteSpecialist = async (req, res) => {
  try {
    const { id } = req.params;
    
    const specialist = await Specialist.findByPk(id);
    if (!specialist) {
      return res.status(404).json({ error: 'Специалист не найден' });
    }
    
    await specialist.destroy();
    res.json({ message: 'Специалист успешно удален' });
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при удалении специалиста' });
  }
};

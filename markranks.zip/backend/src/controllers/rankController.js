const { Rank, Specialist, Customer, Department } = require('../models');
const { Op } = require('sequelize');
const { sequelize } = require('../utils/db');

exports.createRank = async (req, res) => {
  try {
    const { specialistId, customerId, date, speed, efficiency, quality } = req.body;
    
    const existingRank = await Rank.findOne({
      where: { 
        specialistId, 
        date 
      }
    });
    
    if (existingRank) {
      return res.status(400).json({ error: 'Оценка уже существует для этого специалиста на указанную дату' });
    }
    
    const rank = await Rank.create({
      specialistId,
      customerId,
      date,
      speed,
      efficiency,
      quality
    });
    
    res.status(201).json(rank);
  } catch (error) {
    console.error(`Error creating rank: ${error.message}`);
    res.status(500).json({ error: 'Ошибка при создании оценки' });
  }
};

exports.getRanks = async (req, res) => {
  try {
    const { startDate, endDate, specialistId, customerId, departmentId } = req.query;
    
    const where = {};
    
    if (startDate && endDate) {
      where.date = { [Op.between]: [startDate, endDate] };
    }
    
    if (specialistId) where.specialistId = specialistId;
    if (customerId) where.customerId = customerId;
    
    const include = [
      { model: Specialist, attributes: ['id', 'fullName'] },
      { 
        model: Customer, 
        attributes: ['id', 'name'],
        include: [{ 
          model: Department, 
          attributes: ['id', 'name'],
          where: departmentId ? { id: departmentId } : undefined
        }]
      }
    ];
    
    const ranks = await Rank.findAll({
      where,
      include,
      attributes: [
        'id',
        'date',
        'speed',
        'efficiency',
        'quality',
        [sequelize.literal('(speed + efficiency + quality) / 3.0'), 'avg']
      ]
    });
    
    res.json(ranks);
  } catch (error) {
    console.error(`Error fetching ranks: ${error.message}`);
    res.status(500).json({ error: 'Ошибка при получении оценок' });
  }
};

exports.exportRanks = async (req, res) => {
  try {
    const { startDate, endDate, specialistId, customerId, departmentId } = req.query;
    
    const where = {};
    
    if (startDate && endDate) {
      where.date = { [Op.between]: [startDate, endDate] };
    }
    
    if (specialistId) where.specialistId = specialistId;
    if (customerId) where.customerId = customerId;
    
    const include = [
      { model: Specialist, attributes: ['fullName'] },
      { 
        model: Customer, 
        attributes: ['name'],
        include: [{ 
          model: Department, 
          attributes: ['name'],
          where: departmentId ? { id: departmentId } : undefined
        }]
      }
    ];
    
    const ranks = await Rank.findAll({
      where,
      include,
      raw: true,
      attributes: [
        'date',
        'speed',
        'efficiency',
        'quality',
        [sequelize.literal('(speed + efficiency + quality) / 3.0'), 'avg']
      ]
    });
    
    const csvData = [
      ['Специалист', 'Заказчик', 'Подразделение', 'Дата', 'Скорость', 'Оперативность', 'Качество', 'Средний балл'],
      ...ranks.map(rank => [
        rank['Specialist.fullName'],
        rank['Customer.name'],
        rank['Customer.Department.name'],
        rank.date,
        rank.speed,
        rank.efficiency,
        rank.quality,
        rank.avg
      ])
    ].map(row => row.join(',')).join('\n');
    
    res.header('Content-Type', 'text/csv');
    res.attachment('ranks.csv');
    res.send(csvData);
  } catch (error) {
    console.error(`Error exporting ranks: ${error.message}`);
    res.status(500).json({ error: 'Ошибка при экспорте данных' });
  }
};

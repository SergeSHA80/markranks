const { DataTypes } = require('sequelize');
const { sequelize } = require('../utils/db');

const Department = sequelize.define('Department', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING(100),
    allowNull: false,
    unique: true
  }
}, {
  tableName: 'departments',
  timestamps: false
});

module.exports = Department;

const { DataTypes } = require('sequelize');
const { sequelize } = require('../utils/db');
const Specialist = require('./specialist');
const Customer = require('./customer');

const Rank = sequelize.define('Rank', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  specialistId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Specialist,
      key: 'id'
    },
    field: 'specialist_id'
  },
  customerId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Customer,
      key: 'id'
    },
    field: 'customer_id'
  },
  date: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  speed: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1,
      max: 3
    }
  },
  efficiency: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1,
      max: 3
    }
  },
  quality: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1,
      max: 3
    }
  }
}, {
  tableName: 'ranks',
  timestamps: false,
  indexes: [
    {
      unique: true,
      fields: ['specialist_id', 'date']
    }
  ]
});

Rank.belongsTo(Specialist, { foreignKey: 'specialistId' });
Rank.belongsTo(Customer, { foreignKey: 'customerId' });

module.exports = Rank;

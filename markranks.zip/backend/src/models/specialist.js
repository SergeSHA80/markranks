const { DataTypes } = require('sequelize');
const { sequelize } = require('../utils/db');

const Specialist = sequelize.define('Specialist', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  fullName: {
    type: DataTypes.STRING(100),
    allowNull: false,
    unique: true,
    field: 'full_name'
  }
}, {
  tableName: 'specialists',
  timestamps: false
});

module.exports = Specialist;

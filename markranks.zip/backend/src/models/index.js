const { sequelize } = require('../utils/db');
const Department = require('./department');
const Customer = require('./customer');
const Specialist = require('./specialist');
const Rank = require('./rank');

// Определение связей
Department.hasMany(Customer, { foreignKey: 'departmentId' });
Customer.belongsTo(Department, { foreignKey: 'departmentId' });

Specialist.hasMany(Rank, { foreignKey: 'specialistId' });
Rank.belongsTo(Specialist, { foreignKey: 'specialistId' });

Customer.hasMany(Rank, { foreignKey: 'customerId' });
Rank.belongsTo(Customer, { foreignKey: 'customerId' });

module.exports = {
  Department,
  Customer,
  Specialist,
  Rank,
  sequelize
};

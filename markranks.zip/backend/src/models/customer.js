const { DataTypes } = require('sequelize');
const { sequelize } = require('../utils/db');
const Department = require('./department');

const Customer = sequelize.define('Customer', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  departmentId: {
    type: DataTypes.INTEGER,
    references: {
      model: Department,
      key: 'id'
    }
  }
}, {
  tableName: 'customers',
  timestamps: false
});

Customer.belongsTo(Department, { foreignKey: 'departmentId' });

module.exports = Customer;

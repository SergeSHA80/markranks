const express = require('express');
const router = express.Router();
const { getSpecialists } = require('../controllers/specialistController');
const { getDepartments } = require('../controllers/departmentController');
const { getCustomersByDepartment } = require('../controllers/customerController');
const { createRank } = require('../controllers/rankController');

router.get('/specialists', getSpecialists);
router.get('/departments', getDepartments);
router.get('/customers', getCustomersByDepartment);
router.post('/ranks', createRank);

module.exports = router;

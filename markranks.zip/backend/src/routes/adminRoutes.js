const express = require('express');
const router = express.Router();
const authMiddleware = require('../middlewares/authMiddleware');
const departmentController = require('../controllers/departmentController');
const customerController = require('../controllers/customerController');
const specialistController = require('../controllers/specialistController');
const rankController = require('../controllers/rankController');

// Departments
router.get('/departments', authMiddleware, departmentController.getDepartments);
router.post('/departments', authMiddleware, departmentController.createDepartment);
router.put('/departments/:id', authMiddleware, departmentController.updateDepartment);
router.delete('/departments/:id', authMiddleware, departmentController.deleteDepartment);

// Customers
router.get('/customers', authMiddleware, customerController.getCustomers);
router.post('/customers', authMiddleware, customerController.createCustomer);
router.put('/customers/:id', authMiddleware, customerController.updateCustomer);
router.delete('/customers/:id', authMiddleware, customerController.deleteCustomer);

// Specialists
router.get('/specialists', authMiddleware, specialistController.getSpecialists);
router.post('/specialists', authMiddleware, specialistController.createSpecialist);
router.put('/specialists/:id', authMiddleware, specialistController.updateSpecialist);
router.delete('/specialists/:id', authMiddleware, specialistController.deleteSpecialist);

// Ranks
router.get('/ranks', authMiddleware, rankController.getRanks);
router.get('/ranks/export', authMiddleware, rankController.exportRanks);

module.exports = router;

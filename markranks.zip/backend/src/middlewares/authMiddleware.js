const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader) {
      return res.status(401).json({ error: 'Требуется авторизация' });
    }
    
    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    if (decoded.password !== process.env.ADMIN_PASSWORD) {
      return res.status(401).json({ error: 'Неверные учетные данные' });
    }
    
    next();
  } catch (error) {
    console.error(`Authentication error: ${error.message}`);
    return res.status(401).json({ error: 'Ошибка аутентификации' });
  }
};

const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST || 'db',
    port: process.env.DB_PORT || 5432,
    dialect: 'postgres',
    logging: false,
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    },
    retry: {
      match: [/ConnectionError/, /SequelizeConnectionError/],
      max: 5,
      backoffBase: 3000,
      backoffExponent: 1.5
    }
  }
);

const connectDB = async () => {
  let attempts = 0;
  const maxAttempts = 10;
  
  while (attempts < maxAttempts) {
    try {
      await sequelize.authenticate();
      console.log('Database connection established');
      
      await sequelize.sync({ alter: true });
      console.log('Database synchronized');
      
      return;
    } catch (error) {
      attempts++;
      console.error(`Database connection failed (attempt ${attempts}/${maxAttempts}): ${error.message}`);
      
      if (attempts >= maxAttempts) {
        console.error('Unable to connect to database after maximum attempts');
        process.exit(1);
      }
      
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
};

module.exports = { sequelize, connectDB };

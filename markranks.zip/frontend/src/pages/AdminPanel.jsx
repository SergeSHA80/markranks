import React, { useState } from 'react';
// Убрали неиспользуемые импорты Routes, Route, Link
import DepartmentForm from '../components/admin/DepartmentForm';
import CustomerForm from '../components/admin/CustomerForm';
import SpecialistForm from '../components/admin/SpecialistForm';
import ViewRanks from '../components/admin/ViewRanks';

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState('view');
  
  const tabs = [
    { id: 'view', label: 'Просмотр оценок' },
    { id: 'departments', label: 'Подразделения' },
    { id: 'customers', label: 'Заказчики' },
    { id: 'specialists', label: 'Специалисты' },
  ];
  
  return (
    <div className="admin-panel">
      <h1>Администрирование</h1>
      <div className="tabs">
        {tabs.map(tab => (
          <button
            key={tab.id}
            className={activeTab === tab.id ? 'active' : ''}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </div>
      
      <div className="tab-content">
        {activeTab === 'view' && <ViewRanks />}
        {activeTab === 'departments' && <DepartmentForm />}
        {activeTab === 'customers' && <CustomerForm />}
        {activeTab === 'specialists' && <SpecialistForm />}
      </div>
    </div>
  );
};

export default AdminPanel;

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

const AdminLogin = () => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const response = await api.post('/auth/login', { password });
      
      if (response.data.token) {
        localStorage.setItem('admin_token', response.data.token);
        navigate('/admin');
      } else {
        setError('Ошибка авторизации: Неверный ответ сервера');
      }
    } catch (err) {
      setError('Ошибка авторизации: ' + (
        err.response?.data?.error || 
        (err.message.includes('Network Error') ? 'Сервер недоступен' : 'Неизвестная ошибка')
      ));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <form onSubmit={handleSubmit} className="login-form">
        <h2>Вход в админ-панель</h2>
        
        {error && <div className="alert alert-danger">{error}</div>}
        
        <div className="form-group">
          <label>Пароль</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
          />
        </div>
        
        <button 
          type="submit" 
          className="login-button"
          disabled={loading}
        >
          {loading ? 'Вход...' : 'Войти'}
        </button>
      </form>
    </div>
  );
};

export default AdminLogin;
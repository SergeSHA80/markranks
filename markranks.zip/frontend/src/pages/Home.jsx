import React from 'react';
import RatingForm from '../components/main/RatingForm';

const Home = () => {
  return (
    <div>
      <h1>Оценка специалиста поддержки</h1>
      <RatingForm />
    </div>
  );
};

export default Home;

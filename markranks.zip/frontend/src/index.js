import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

const removePreloader = () => {
  const preloader = document.querySelector('.loading-container');
  if (preloader) {
    preloader.style.display = 'none';
  }
};

document.addEventListener('DOMContentLoaded', removePreloader);
window.addEventListener('load', removePreloader);

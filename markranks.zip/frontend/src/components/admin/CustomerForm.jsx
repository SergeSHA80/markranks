import React, { useState, useEffect } from 'react';
import api from '../../services/api';

const CustomerForm = () => {
  const [customers, setCustomers] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [formData, setFormData] = useState({ id: '', name: '', departmentId: '' });
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [custResponse, deptResponse] = await Promise.all([
        api.get('/admin/customers'),
        api.get('/admin/departments')
      ]);
      
      setCustomers(custResponse.data);
      setDepartments(deptResponse.data);
    } catch (error) {
      console.error('Ошибка загрузки данных:', error);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      if (editing) {
        await api.put(`/admin/customers/${formData.id}`, formData);
      } else {
        await api.post('/admin/customers', formData);
      }
      
      setFormData({ id: '', name: '', departmentId: '' });
      setEditing(false);
      loadData();
    } catch (error) {
      console.error('Ошибка сохранения заказчика:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (customer) => {
    setFormData(customer);
    setEditing(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Вы уверены, что хотите удалить заказчика?')) {
      try {
        await api.delete(`/admin/customers/${id}`);
        loadData();
      } catch (error) {
        console.error('Ошибка удаления заказчика:', error);
      }
    }
  };

  return (
    <div>
      <h2>{editing ? 'Редактирование заказчика' : 'Добавление заказчика'}</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Название</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Подразделение</label>
          <select
            name="departmentId"
            value={formData.departmentId}
            onChange={handleChange}
            required
          >
            <option value="">Выберите подразделение</option>
            {departments.map(dept => (
              <option key={dept.id} value={dept.id}>{dept.name}</option>
            ))}
          </select>
        </div>
        <button type="submit" disabled={loading}>
          {editing ? 'Обновить' : 'Добавить'}
        </button>
        {editing && (
          <button type="button" onClick={() => { setEditing(false); setFormData({ id: '', name: '', departmentId: '' }); }}>
            Отмена
          </button>
        )}
      </form>
      
      <h3>Список заказчиков</h3>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Название</th>
            <th>Подразделение</th>
            <th>Действия</th>
          </tr>
        </thead>
        <tbody>
          {customers.map(cust => (
            <tr key={cust.id}>
              <td>{cust.id}</td>
              <td>{cust.name}</td>
              <td>{cust.Department ? cust.Department.name : 'N/A'}</td>
              <td>
                <button onClick={() => handleEdit(cust)}>Изменить</button>
                <button onClick={() => handleDelete(cust.id)}>Удалить</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CustomerForm;

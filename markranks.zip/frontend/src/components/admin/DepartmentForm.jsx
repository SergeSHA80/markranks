import React, { useState, useEffect } from 'react';
import api from '../../services/api';

const DepartmentForm = () => {
  const [departments, setDepartments] = useState([]);
  const [formData, setFormData] = useState({ id: '', name: '' });
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadDepartments();
  }, []);

  const loadDepartments = async () => {
    try {
      const response = await api.get('/admin/departments');
      setDepartments(response.data);
    } catch (error) {
      console.error('Ошибка загрузки подразделений:', error);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      if (editing) {
        await api.put(`/admin/departments/${formData.id}`, formData);
      } else {
        await api.post('/admin/departments', formData);
      }
      
      setFormData({ id: '', name: '' });
      setEditing(false);
      loadDepartments();
    } catch (error) {
      console.error('Ошибка сохранения подразделения:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (department) => {
    setFormData(department);
    setEditing(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Вы уверены, что хотите удалить подразделение?')) {
      try {
        await api.delete(`/admin/departments/${id}`);
        loadDepartments();
      } catch (error) {
        console.error('Ошибка удаления подразделения:', error);
      }
    }
  };

  return (
    <div>
      <h2>{editing ? 'Редактирование подразделения' : 'Добавление подразделения'}</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Название</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" disabled={loading}>
          {editing ? 'Обновить' : 'Добавить'}
        </button>
        {editing && (
          <button type="button" onClick={() => { setEditing(false); setFormData({ id: '', name: '' }); }}>
            Отмена
          </button>
        )}
      </form>
      
      <h3>Список подразделений</h3>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Название</th>
            <th>Действия</th>
          </tr>
        </thead>
        <tbody>
          {departments.map(dept => (
            <tr key={dept.id}>
              <td>{dept.id}</td>
              <td>{dept.name}</td>
              <td>
                <button onClick={() => handleEdit(dept)}>Изменить</button>
                <button onClick={() => handleDelete(dept.id)}>Удалить</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DepartmentForm;

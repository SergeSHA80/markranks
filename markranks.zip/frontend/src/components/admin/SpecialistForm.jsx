import React, { useState, useEffect } from 'react';
import api from '../../services/api';

const SpecialistForm = () => {
  const [specialists, setSpecialists] = useState([]);
  const [formData, setFormData] = useState({ id: '', fullName: '' });
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadSpecialists();
  }, []);

  const loadSpecialists = async () => {
    try {
      const response = await api.get('/admin/specialists');
      setSpecialists(response.data);
    } catch (error) {
      console.error('Ошибка загрузки специалистов:', error);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      if (editing) {
        await api.put(`/admin/specialists/${formData.id}`, { fullName: formData.fullName });
      } else {
        await api.post('/admin/specialists', { fullName: formData.fullName });
      }
      
      setFormData({ id: '', fullName: '' });
      setEditing(false);
      loadSpecialists();
    } catch (error) {
      console.error('Ошибка сохранения специалиста:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (specialist) => {
    setFormData(specialist);
    setEditing(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Вы уверены, что хотите удалить специалиста?')) {
      try {
        await api.delete(`/admin/specialists/${id}`);
        loadSpecialists();
      } catch (error) {
        console.error('Ошибка удаления специалиста:', error);
      }
    }
  };

  return (
    <div>
      <h2>{editing ? 'Редактирование специалиста' : 'Добавление специалиста'}</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>ФИО</label>
          <input
            type="text"
            name="fullName"
            value={formData.fullName}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" disabled={loading}>
          {editing ? 'Обновить' : 'Добавить'}
        </button>
        {editing && (
          <button type="button" onClick={() => { setEditing(false); setFormData({ id: '', fullName: '' }); }}>
            Отмена
          </button>
        )}
      </form>
      
      <h3>Список специалистов</h3>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>ФИО</th>
            <th>Действия</th>
          </tr>
        </thead>
        <tbody>
          {specialists.map(spec => (
            <tr key={spec.id}>
              <td>{spec.id}</td>
              <td>{spec.fullName}</td>
              <td>
                <button onClick={() => handleEdit(spec)}>Изменить</button>
                <button onClick={() => handleDelete(spec.id)}>Удалить</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default SpecialistForm;

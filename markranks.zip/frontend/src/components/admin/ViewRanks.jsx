import React, { useState, useEffect, useCallback } from 'react';
import { CSVLink } from 'react-csv';
import api from '../../services/api';
import FilterPanel from '../common/FilterPanel';
import Table from '../common/Table';

const ViewRanks = () => {
  const [ranks, setRanks] = useState([]);
  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    specialistId: '',
    customerId: '',
    departmentId: ''
  });
  
  const [specialists, setSpecialists] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [departments, setDepartments] = useState([]);

  // Используем useCallback для стабильной ссылки на функцию
  const loadRanks = useCallback(async () => {
    try {
      const { startDate, endDate, specialistId, customerId, departmentId } = filters;
      const params = {};
      
      if (startDate && endDate) {
        params.startDate = startDate;
        params.endDate = endDate;
      }
      
      if (specialistId) params.specialistId = specialistId;
      if (customerId) params.customerId = customerId;
      if (departmentId) params.departmentId = departmentId;
      
      const response = await api.get('/admin/ranks', { params });
      setRanks(response.data);
    } catch (error) {
      console.error('Ошибка загрузки оценок:', error);
    }
  }, [filters]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [specs, depts, custs] = await Promise.all([
          api.get('/admin/specialists'),
          api.get('/admin/departments'),
          api.get('/admin/customers')
        ]);
        
        setSpecialists(specs.data);
        setDepartments(depts.data);
        setCustomers(custs.data);
        loadRanks();
      } catch (error) {
        console.error('Ошибка загрузки данных:', error);
      }
    };
    
    fetchData();
  }, [loadRanks]); // Добавили loadRanks в зависимости

  const handleFilterChange = (name, value) => {
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const handleApplyFilters = () => {
    loadRanks();
  };

  const columns = [
    { Header: 'Специалист', accessor: 'Specialist.fullName' },
    { Header: 'Заказчик', accessor: 'Customer.name' },
    { Header: 'Подразделение', accessor: 'Customer.Department.name' },
    { Header: 'Дата', accessor: 'date' },
    { Header: 'Скорость', accessor: 'speed' },
    { Header: 'Оперативность', accessor: 'efficiency' },
    { Header: 'Качество', accessor: 'quality' },
    { Header: 'Средний балл', accessor: 'avg' }
  ];

  return (
    <div className="view-ranks">
      <div className="header">
        <h2>Просмотр оценок</h2>
        <CSVLink 
          data={ranks} 
          filename="оценки_специалистов.csv"
          className="export-btn"
        >
          Экспорт в CSV
        </CSVLink>
      </div>
      
      <FilterPanel
        filters={filters}
        specialists={specialists}
        customers={customers}
        departments={departments}
        onFilterChange={handleFilterChange}
        onApply={handleApplyFilters}
      />
      
      <Table 
        data={ranks} 
        columns={columns} 
        defaultPageSize={10}
      />
    </div>
  );
};

export default ViewRanks;

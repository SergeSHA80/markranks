import React from 'react';

const FilterPanel = ({ filters, specialists, customers, departments, onFilterChange, onApply }) => {
  return (
    <div className="filter-panel">
      <div className="filter-row">
        <div className="filter-group">
          <label>Период с</label>
          <input
            type="date"
            value={filters.startDate}
            onChange={(e) => onFilterChange('startDate', e.target.value)}
          />
        </div>
        <div className="filter-group">
          <label>по</label>
          <input
            type="date"
            value={filters.endDate}
            onChange={(e) => onFilterChange('endDate', e.target.value)}
          />
        </div>
      </div>
      
      <div className="filter-row">
        <div className="filter-group">
          <label>Специалист</label>
          <select
            value={filters.specialistId}
            onChange={(e) => onFilterChange('specialistId', e.target.value)}
          >
            <option value="">Все</option>
            {specialists.map(s => (
              <option key={s.id} value={s.id}>{s.fullName}</option>
            ))}
          </select>
        </div>
        
        <div className="filter-group">
          <label>Заказчик</label>
          <select
            value={filters.customerId}
            onChange={(e) => onFilterChange('customerId', e.target.value)}
          >
            <option value="">Все</option>
            {customers.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        
        <div className="filter-group">
          <label>Подразделение</label>
          <select
            value={filters.departmentId}
            onChange={(e) => onFilterChange('departmentId', e.target.value)}
          >
            <option value="">Все</option>
            {departments.map(d => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </select>
        </div>
      </div>
      
      <button onClick={onApply}>Применить фильтры</button>
    </div>
  );
};

export default FilterPanel;

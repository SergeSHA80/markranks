import React from 'react';
import { FaStar } from 'react-icons/fa';

const StarRating = ({ rating, onRatingChange }) => {
  return (
    <div className="star-rating">
      {[1, 2, 3].map(star => (
        <FaStar 
          key={star}
          className={star <= rating ? 'active' : ''}
          onClick={() => onRatingChange(star)}
          size={24}
        />
      ))}
    </div>
  );
};

export default StarRating;

import React, { useState, useEffect } from 'react';
import Cookies from 'universal-cookie';
import StarRating from '../common/StarRating';
import api from '../../services/api';

const RatingForm = () => {
  const cookies = new Cookies();
  const [specialists, setSpecialists] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [departments, setDepartments] = useState([]);
  
  const [formData, setFormData] = useState({
    specialistId: '',
    departmentId: '',
    customerId: cookies.get('customer') || '',
    date: new Date().toISOString().split('T')[0],
    speed: 0,
    efficiency: 0,
    quality: 0
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [specs, depts] = await Promise.all([
          api.get('/specialists'),
          api.get('/departments')
        ]);
        
        setSpecialists(specs.data);
        setDepartments(depts.data);
        
        if (formData.departmentId) {
          const custs = await api.get(`/customers?departmentId=${formData.departmentId}`);
          setCustomers(custs.data);
        }
      } catch (error) {
        console.error('Ошибка загрузки данных:', error);
      }
    };
    
    fetchData();
  }, [formData.departmentId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    if (name === 'customerId') {
      cookies.set('customer', value, { path: '/', maxAge: 30 * 24 * 60 * 60 });
    }
  };

  const handleDepartmentChange = (e) => {
    const departmentId = e.target.value;
    setFormData(prev => ({ 
      ...prev, 
      departmentId,
      customerId: '' 
    }));
    setCustomers([]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/ranks', formData);
      alert('Оценка успешно сохранена!');
      setFormData(prev => ({
        ...prev,
        specialistId: '',
        speed: 0,
        efficiency: 0,
        quality: 0
      }));
    } catch (error) {
      alert('Ошибка при сохранении оценки: ' + (error.response?.data?.error || error.message));
    }
  };

  return (
    <form onSubmit={handleSubmit} className="rating-form">
      <div className="form-group">
        <label>Специалист</label>
        <select 
          name="specialistId"
          value={formData.specialistId}
          onChange={handleChange}
          required
        >
          <option value="">Выберите специалиста</option>
          {specialists.map(s => (
            <option key={s.id} value={s.id}>{s.fullName}</option>
          ))}
        </select>
      </div>
      
      <div className="form-group">
        <label>Подразделение</label>
        <select 
          name="departmentId"
          value={formData.departmentId}
          onChange={handleDepartmentChange}
          required
        >
          <option value="">Выберите подразделение</option>
          {departments.map(d => (
            <option key={d.id} value={d.id}>{d.name}</option>
          ))}
        </select>
      </div>
      
      <div className="form-group">
        <label>Заказчик</label>
        <select 
          name="customerId"
          value={formData.customerId}
          onChange={handleChange}
          required
        >
          <option value="">Выберите заказчика</option>
          {customers.map(c => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>
      
      <div className="form-group">
        <label>Дата смены</label>
        <input 
          type="date" 
          name="date"
          value={formData.date}
          onChange={handleChange}
          required
        />
      </div>
      
      <div className="rating-category">
        <label>Скорость реагирования</label>
        <StarRating 
          rating={formData.speed} 
          onRatingChange={(rating) => setFormData(prev => ({ ...prev, speed: rating }))} 
        />
      </div>
      
      <div className="rating-category">
        <label>Оперативность</label>
        <StarRating 
          rating={formData.efficiency} 
          onRatingChange={(rating) => setFormData(prev => ({ ...prev, efficiency: rating }))} 
        />
      </div>
      
      <div className="rating-category">
        <label>Качество</label>
        <StarRating 
          rating={formData.quality} 
          onRatingChange={(rating) => setFormData(prev => ({ ...prev, quality: rating }))} 
        />
      </div>
      
      <button type="submit" className="submit-btn">Отправить оценку</button>
    </form>
  );
};

export default RatingForm;

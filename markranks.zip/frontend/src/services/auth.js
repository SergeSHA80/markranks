import api from './api';

export const login = async (password) => {
  const response = await api.post('/auth/login', { password });
  return response.data.token;
};

export const checkAuth = async () => {
  try {
    await api.get('/auth/check');
    return true;
  } catch (error) {
    return false;
  }
};

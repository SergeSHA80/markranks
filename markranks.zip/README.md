# MarkRanks - Система оценки специалистов поддержки

## Описание
Веб-приложение для сбора и анализа оценок специалистов поддержки отдела маркировки.

## Технологический стек
- Frontend: React
- Backend: Node.js (Express)
- Database: PostgreSQL

## Запуск проекта
1. Создать файл .env в корне проекта:
```bash
cp .env.example .env
```
2. Запустить команду:
```bash
docker-compose up --build -d
```
3. Приложение будет доступно:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:5000

## Администрирование
Для входа в админ-панель используйте пароль, указанный в `ADMIN_PASSWORD` в файле .env.
